------------------------------------------------------------------------
----                                                                ----
---- WF68K30L IP Core: Data register logic.                         ----
----                                                                ----
---- Description:                                                   ----
---- These are the eight data registers. The logic provides two     ----
---- read and two write ports providing simultaneos access. For     ----
---- more information refer to the MC68030 User' Manual.            ----
----                                                                ----
---- Author(s):                                                     ----
---- - Wolfgang Foerster, wf@experiment-s.de; wf@inventronik.de     ----
----                                                                ----
------------------------------------------------------------------------
----                                                                ----
---- Copyright � 2014-2019 Wolfgang Foerster Inventronik GmbH.      ----
----                                                                ----
---- This documentation describes Open Hardware and is licensed     ----
---- under the CERN OHL v. 1.2. You may redistribute and modify     ----
---- this documentation under the terms of the CERN OHL v.1.2.      ----
---- (http://ohwr.org/cernohl). This documentation is distributed   ----
---- WITHOUT ANY EXPRESS OR IMPLIED WARRANTY, INCLUDING OF          ----
---- MERCHANTABILITY, SATISFACTORY QUALITY AND FITNESS FOR A        ----
---- PARTICULAR PURPOSE. Please see the CERN OHL v.1.2 for          ----
---- applicable conditions                                          ----
----                                                                ----
------------------------------------------------------------------------
-- 
-- Revision History
-- 
-- Revision 2K14B 20141201 WF
--   Initial Release.
-- FalconFPGA modifications (David Dunne, github.com/dave-1024/falconfpga), CERN OHL v1.2.
-- Changes are tagged Fnn in the code. Dates are from git history.
-- Base: WF68K30L 2K19A (this repo's import of 2026-09-24).
--   2026-10-03 F56: combinational loops and BF_NZ latch removed; hazard selects.
-- 

library work;
use work.WF68K30L_PKG.all;

library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;

entity WF68K30L_DATA_REGISTERS is
    port (
        CLK                 : in std_logic;
        RESET               : in bit;

        -- Data lines:
        DR_IN_1             : in std_logic_vector(31 downto 0);
        DR_IN_2             : in std_logic_vector(31 downto 0);
        DR_OUT_1            : out std_logic_vector(31 downto 0);
        DR_OUT_2            : out std_logic_vector(31 downto 0);
        
        -- Registers controls:
        DR_SEL_WR_1         : in std_logic_vector(2 downto 0);
        DR_SEL_WR_2         : in std_logic_vector(2 downto 0);
        DR_SEL_RD_1         : in std_logic_vector(2 downto 0);
        DR_SEL_RD_2         : in std_logic_vector(2 downto 0);
        DR_SEL_ADH_2        : in std_logic_vector(2 downto 0); -- F56: data hazard check selects
        DR_SEL_ADH_3        : in std_logic_vector(2 downto 0);
        DR_FC_SEL           : in std_logic_vector(2 downto 0) := "000"; -- [PMMU3] PFLUSH/PLOAD/PTEST Dn FC operand
        DR_FC_OUT           : out std_logic_vector(2 downto 0);
        DR_WR_1             : in bit;
        DR_WR_2             : in bit;
        DR_MARK_USED        : in bit;
        USE_DPAIR           : in boolean;
        DR_IN_USE           : out bit;
        DR_IDX_SEL          : in std_logic_vector(2 downto 0) := "000"; -- [F97] index Dn of the last ext word
        DR_IDX_OUT          : out std_logic_vector(31 downto 0);        -- [F97] live value of that Dn
        DR_IDX_PEND         : out bit;                                  -- [F97] that Dn still has a write-back pending
        UNMARK              : in bit;
        
        OP_SIZE             : in OP_SIZETYPE;
        DBG_DR              : out std_logic_vector(255 downto 0) -- [F77] DIAG_DUMP: D7..D0
    );
end entity WF68K30L_DATA_REGISTERS;
    
architecture BEHAVIOUR of WF68K30L_DATA_REGISTERS is
type DR_TYPE is array(0 to 7) of std_logic_vector(31 downto 0);
signal DR               : DR_TYPE; -- Data registers D0 to D7.
signal DR_PNTR_WR_1     : integer range 0 to 7;
signal DR_PNTR_WR_2     : integer range 0 to 7;
signal DR_PNTR_RD_1     : integer range 0 to 7;
signal DR_PNTR_RD_2     : integer range 0 to 7;
signal DR_SEL_WR_I1     : std_logic_vector(2 downto 0);
signal DR_SEL_WR_I2     : std_logic_vector(2 downto 0);
signal DR_USED_1        : std_logic_vector(3 downto 0);
signal DR_USED_2        : std_logic_vector(3 downto 0);
begin
    DBG_DR <= DR(7) & DR(6) & DR(5) & DR(4) & DR(3) & DR(2) & DR(1) & DR(0); -- [F77]
    INBUFFER: process
    begin
        wait until CLK = '1' and CLK' event;
        if DR_MARK_USED = '1' then
            DR_SEL_WR_I1 <= DR_SEL_WR_1;
            DR_SEL_WR_I2 <= DR_SEL_WR_2;
        end if;
    end process INBUFFER;

    DR_PNTR_WR_1 <= conv_integer(DR_SEL_WR_I1);
    DR_PNTR_WR_2 <= conv_integer(DR_SEL_WR_I2);
    DR_PNTR_RD_1 <= conv_integer(DR_SEL_RD_1);
    DR_PNTR_RD_2 <= conv_integer(DR_SEL_RD_2);

    P_IN_USE: process
    begin
        wait until CLK = '1' and CLK' event;
        if RESET = '1' or UNMARK = '1' then
            DR_USED_1(3) <= '0';
            DR_USED_2(3) <= '0';
        elsif DR_MARK_USED = '1' then
            DR_USED_1 <= '1' & DR_SEL_WR_1;
            if USE_DPAIR = true then
                DR_USED_2 <= '1' & DR_SEL_WR_2;
            end if;
        end if;
    end process P_IN_USE;

    -- F56: compared with the hazard selects, not with read port 2 itself (read port 2
    -- follows INIT_ENTRY for BFINS, which is decoded from NEXT_FETCH_STATE).
    DR_IN_USE <= '1' when DR_USED_1(3) = '1' and DR_USED_1(2 downto 0) = DR_SEL_RD_1 else
                 '1' when DR_USED_1(3) = '1' and DR_USED_1(2 downto 0) = DR_SEL_ADH_2 else
                 '1' when DR_USED_1(3) = '1' and DR_USED_1(2 downto 0) = DR_SEL_ADH_3 else
                 '1' when DR_USED_2(3) = '1' and DR_USED_2(2 downto 0) = DR_SEL_RD_1 else
                 '1' when DR_USED_2(3) = '1' and DR_USED_2(2 downto 0) = DR_SEL_ADH_2 else
                 '1' when DR_USED_2(3) = '1' and DR_USED_2(2 downto 0) = DR_SEL_ADH_3 else '0';

    -- [F97] Forwarding for the index register: a full-format ext word latches INDEX before the previous
    -- instruction's write-back of that Dn; the address unit re-reads it here until the write-back has landed.
    DR_IDX_OUT <= DR(conv_integer(DR_IDX_SEL));
    DR_IDX_PEND <= '1' when DR_USED_1(3) = '1' and DR_USED_1(2 downto 0) = DR_IDX_SEL else
                   '1' when DR_USED_2(3) = '1' and DR_USED_2(2 downto 0) = DR_IDX_SEL else '0';
    DR_OUT_1 <= DR(DR_PNTR_RD_1);
    DR_OUT_2 <= DR(DR_PNTR_RD_2);
    DR_FC_OUT <= DR(conv_integer(DR_FC_SEL))(2 downto 0); -- [PMMU3] MC68030UM p. 9-64: FC = Dn bits 2-0

    REGISTERS: process
    begin
        wait until CLK = '1' and CLK' event;
        if RESET = '1' then
            DR <= (others => (others => '0'));
        end if;
        if DR_WR_1 = '1' then
            case OP_SIZE is
                when LONG => DR(DR_PNTR_WR_1) <= DR_IN_1;
                when WORD => DR(DR_PNTR_WR_1)(15 downto 0) <= DR_IN_1(15 downto 0);
                when Byte => DR(DR_PNTR_WR_1)(7 downto 0) <= DR_IN_1(7 downto 0);
            end case;
        end if;
        if DR_WR_2 = '1' then
            case OP_SIZE is
                when LONG => DR(DR_PNTR_WR_2) <= DR_IN_2;
                when WORD => DR(DR_PNTR_WR_2)(15 downto 0) <= DR_IN_2(15 downto 0);
                when Byte => DR(DR_PNTR_WR_2)(7 downto 0) <= DR_IN_2(7 downto 0);
            end case;
        end if;
    end process REGISTERS;
end BEHAVIOUR;
