------------------------------------------------------------------------
----                                                                ----
---- WF68K30L IP Core: Address register logic.                      ----
----                                                                ----
---- Description:                                                   ----
---- This module provides the address registers, stack pointers,    ----
---- the address arithmetics, the program counter logic and the SFC ----
---- and DFC registers. The address registers are accessible by two ----
---- read and two write ports simultaneously. For more information  ----
---- refer to the MC68030 User' Manual.                             ----
----                                                                ----
---- Author(s):                                                     ----
---- - Wolfgang Foerster, wf@experiment-s.de; wf@inventronik.de     ----
----                                                                ----
------------------------------------------------------------------------
----                                                                ----
---- Copyright © 2014-2019 Wolfgang Foerster Inventronik GmbH.      ----
----                                                                ----
---- This documentation describes Open Hardware and is licensed     ----
---- under the CERN OHL v. 1.2. You may redistribute and modify     ----
---- this documentation under the terms of the CERN OHL v.1.2.      ----
---- (http://ohwr.org/cernohl). This documentation is distributed   ----
---- WITHOUT ANY EXPRESS OR IMPLIED WARRANTY, INCLUDING OF          ----
---- MERCHANTABILITY, SATISFACTORY QUALITY AND FITNESS FOR A        ----
---- PARTICULAR PURPOSE. Please see the CERN OHL v.1.2 for          ----
---- applicable conditions                                          ----
----                                                                ----
------------------------------------------------------------------------
-- 
-- Revision History
-- 
-- Revision 2K14B 20141201 WF
--   Initial Release.
-- Revision 2K16A 20160620 WF
--   Minor optimizations.
-- Revision 2K18A 20180620 WF
--   Changed ADR_ATN logic to be valid one clock cycle earlier.
--   Fixed PC restoring during exception processing.
--   Fixed the writing ISP_REG during EXG instruction with two address registers.
--   Fixed writing the stack pointer registers (MSBIT is used now).
--   The address registers are always written long.
--   Bugfix: exception handler do not increment and decrement the USP any more.
--   MOVEM-Fix: the effective address in memory to register is stored (STORE_AEFF) not to be overwritten in case the addressing register is also loaded.
-- Revision 2K19A 2019## WF
--   Removed ADR_ATN. We do not need this any more.
-- FalconFPGA modifications (David Dunne, github.com/dave-1024/falconfpga), CERN OHL v1.2.
-- Changes are tagged Fnn in the code. Dates are from git history.
-- Base: WF68K30L 2K19A (this repo's import of 2026-09-24).
--   2026-09-30 F8: master stack decrement when building frames with M=1.
--   2026-09-30 F16/F17/F19/F20: full-format EA base/index suppress (An and PC).
--   2026-09-30 COLD: MSBIT reset; single ISP write chain.
--   2026-10-14 DIAG: DBG_EXC/DBG_ADR/DBG_A5 debug ports (unused ports are removed).
-- 

use work.WF68K30L_PKG.all;

library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;

entity WF68K30L_ADDRESS_REGISTERS is
    port (
        CLK                 : in std_logic;
        RESET               : in bit;

        -- Address and data:
        AR_IN_1             : in std_logic_vector(31 downto 0);
        AR_IN_2             : in std_logic_vector(31 downto 0);
        AR_OUT_1            : out std_logic_vector(31 downto 0);
        AR_OUT_2            : out std_logic_vector(31 downto 0);
        INDEX_IN            : in std_logic_vector(31 downto 0);
        INDEX_LIVE          : in std_logic_vector(31 downto 0) := x"00000000"; -- [F97]
        INDEX_PEND          : in bit := '0';                                   -- [F97]
        IDX_SEL             : out std_logic_vector(2 downto 0);                -- [F97]
        PC                  : out std_logic_vector(31 downto 0); -- Program counter (or sPC) always word aligned.
        PC_EW_OFFSET        : in std_logic_vector(3 downto 0); -- Offset to the first address extension word.
        FETCH_MEM_ADR       : in bit;
        STORE_ADR_FORMAT    : in bit;
        STORE_ABS_HI        : in bit;
        STORE_ABS_LO        : in bit;
        STORE_D16           : in bit;
        STORE_D32_LO        : in bit;
        STORE_D32_HI        : in bit;
        STORE_DISPL         : in bit;
        STORE_MEM_ADR       : in bit;
        STORE_OD_HI         : in bit;
        STORE_OD_LO         : in bit;
        STORE_AEFF          : in bit;
        OP_SIZE             : in OP_SIZETYPE;

        ADR_OFFSET          : in std_logic_vector(31 downto 0);
        ADR_MARK_USED       : in bit;
        ADR_FAST            : in bit; -- [F3] Load the write address without the calculation delay.
        USE_APAIR           : in boolean;
        ADR_IN_USE          : out bit;

        ADR_MODE            : in std_logic_vector(2 downto 0);
        AMODE_SEL           : in std_logic_vector(2 downto 0);
        USE_DREG            : in bit; -- Use data register as address pointer.
        ADR_EFF             : out std_logic_vector(31 downto 0); -- This is the effective address.
        ADR_EFF_WB          : out std_logic_vector(31 downto 0); -- This is the effective address.

        DFC                 : out std_logic_vector(2 downto 0);
        DFC_WR              : in bit;
        SFC                 : out std_logic_vector(2 downto 0);
        SFC_WR              : in bit;

        ISP_DEC             : in bit;
        ISP_EARLY           : in bit; -- [XT1] Next stack long requested in the DATA_RDY clock: use ISP_M4.
        ISP_RD              : in bit;
        ISP_WR              : in bit;
        MSP_RD              : in bit;
        MSP_WR              : in bit;
        USP_RD              : in bit;
        USP_WR              : in bit;

        -- Registers controls:
        AR_MARK_USED        : in bit;
        AR_IN_USE           : out bit;
        AR_SEL_RD_1         : in std_logic_vector(2 downto 0);
        AR_SEL_RD_2         : in std_logic_vector(2 downto 0);
        AR_SEL_WR_1         : in std_logic_vector(2 downto 0);
        AR_SEL_WR_2         : in std_logic_vector(2 downto 0);
        AR_DEC              : in bit; -- Address register decrement.
        AR_INC              : in bit; -- Address register increment.
        AR_WR_1             : in bit; -- Address register write.
        AR_WR_2             : in bit; -- Address register write.
        UNMARK              : in bit;

        EXT_WORD            : in std_logic_vector(15 downto 0);

        MBIT                : in std_logic;
        SBIT                : in std_logic;

        SP_ADD_DISPL        : in bit;
        RESTORE_ISP_PC      : in bit;

        -- Other controls:
        DISPLACEMENT        : in std_logic_vector(31 downto 0);
        PC_ADD_DISPL        : in bit;
        PC_INC              : in bit; -- Program counter increment.
        PC_LOAD             : in bit; -- Program counter write.
        PC_RESTORE          : in bit;
        PC_OFFSET           : in std_logic_vector(7 downto 0);
        DBG_A5              : out std_logic_vector(31 downto 0); -- FalconFPGA DIAG (A5 for the exception probe)
        DBG_SP              : out std_logic_vector(31 downto 0); -- FalconFPGA DIAG STR: ISP
        DBG_AR              : out std_logic_vector(319 downto 0) -- [F77] DIAG_DUMP: A0..A6, USP, ISP, MSP
    );
end entity WF68K30L_ADDRESS_REGISTERS;
    
architecture BEHAVIOR of WF68K30L_ADDRESS_REGISTERS is
signal IDX_TRK : bit := '0';                                   -- [F97] INDEX follows the live Dn
signal IDX_N   : std_logic_vector(2 downto 0) := "000";
signal IDX_L   : std_logic := '0';
type AR_TYPE is array(0 to 6) of std_logic_vector(31 downto 0);
signal ADR_EFF_I        : std_logic_vector(31 downto 0);
signal AR               : AR_TYPE; -- Address registers A0 to A6.
signal AR_OUT_1_I       : std_logic_vector(31 downto 0);
signal AR_OUT_2_I       : std_logic_vector(31 downto 0);
signal ADR_WB           : std_logic_vector(32 downto 0);
signal AR_PNTR_1        : integer range 0 to 7;
signal AR_PNTR_2        : integer range 0 to 7;
signal AR_PNTR_WB_1     : integer range 0 to 7;
signal AR_PNTR_WB_2     : integer range 0 to 7;
signal AR_USED_1        : std_logic_vector(3 downto 0);
signal AR_USED_2        : std_logic_vector(3 downto 0);
signal B_S              : std_logic := '0'; -- Base register suppress.
signal BD_SIZE          : std_logic_vector(1 downto 0); -- Indexed / Indirect.
signal DFC_REG          : std_logic_vector(2 downto 0); -- Special function code registers.
signal F_E              : std_logic; -- Full extension word.
signal I_IS             : std_logic_vector(2 downto 0); -- Indexed / Indirect.
signal I_S              : std_logic; -- Index suppress.
signal ISP_REG          : std_logic_vector(31 downto 0); -- Interrupt stack pointer (refers to A7'' in the supervisor mode).
signal ISP_M4           : std_logic_vector(31 downto 0) := (others => '0'); -- [XT1] Registered ISP - 4 (one clock behind ISP_REG).
signal MSBIT            : std_logic_vector(1 downto 0);
signal MSP_REG          : std_logic_vector(31 downto 0); -- Master stack pointer (refers to A7' in the supervisor mode).
signal PC_I             : std_logic_vector(31 downto 0); -- Active program counter.
signal SCALE            : std_logic_vector(1 downto 0); -- Scale information for the index.
signal SFC_REG          : std_logic_vector(2 downto 0); -- Special function code registers.
signal USP_REG          : std_logic_vector(31 downto 0); -- User stack pointer (refers to A7 in the user mode.).
begin
    IDX_SEL <= EXT_WORD(14 downto 12) when STORE_ADR_FORMAT = '1' else IDX_N; -- [F97]
    DBG_A5 <= AR(5); -- FalconFPGA DIAG
    DBG_SP <= ISP_REG; -- FalconFPGA DIAG STR
    DBG_AR <= AR(0) & AR(1) & AR(2) & AR(3) & AR(4) & AR(5) & AR(6) & USP_REG & ISP_REG & MSP_REG; -- [F77]
    INBUFFER: process
    begin
        wait until CLK = '1' and CLK' event;
        if AR_MARK_USED = '1' then
            AR_PNTR_WB_1 <= conv_integer(AR_SEL_WR_1);
            AR_PNTR_WB_2 <= conv_integer(AR_SEL_WR_2);
        end if;
    end process INBUFFER;

    AR_PNTR_1 <= conv_integer(AR_SEL_RD_1);
    AR_PNTR_2 <= conv_integer(AR_SEL_RD_2);

    P_IN_USE: process
    variable DELAY  : boolean;
    begin
        wait until CLK = '1' and CLK' event;
        if RESET = '1' or UNMARK = '1' then
            AR_USED_1(3) <= '0';
            AR_USED_2(3) <= '0';
            -- [COLD] 68030 reset SR is S=1 M=0.  MSBIT had no reset and
            -- only updated on AR_MARK_USED, so move.l %sp could write
            -- USP/MSP while exception stacking still used ISP.
            MSBIT <= "01";
        elsif AR_MARK_USED = '1' then
            AR_USED_1 <= '1' & AR_SEL_WR_1;
            if USE_APAIR = true then
                AR_USED_2 <= '1' & AR_SEL_WR_2;
            end if;
            MSBIT <= MBIT & SBIT;
        end if;
        --
        if RESET = '1' or UNMARK = '1' then
            ADR_WB(32) <= '0';
            DELAY := false;
        elsif ADR_MARK_USED = '1' and ADR_FAST = '1' then
            ADR_WB <= '1' & ADR_EFF_I; -- [F3] MOVEM: the next register's address is already calculated.
            DELAY := false;
        elsif ADR_MARK_USED = '1' then
            DELAY := true; -- One clock cycle address calculation delay.
        elsif DELAY = true then
            ADR_WB <= '1' & ADR_EFF_I;
            DELAY := false;
        end if;
    end process P_IN_USE; 

    AR_IN_USE <= '0' when AR_USED_1(2 downto 0) = "111" and SBIT = '1' and MSBIT(1) /= MBIT else -- Wrong stack pointer.
                 '0' when AR_USED_2(2 downto 0) = "111" and SBIT = '1' and MSBIT(1) /= MBIT else -- Wrong stack pointer.
                 '1' when AR_USED_1(3) = '1' and AR_USED_1(2 downto 0) = AR_SEL_RD_1 else
                 '1' when AR_USED_1(3) = '1' and AR_USED_1(2 downto 0) = AR_SEL_RD_2 else
                 '1' when AR_USED_2(3) = '1' and AR_USED_2(2 downto 0) = AR_SEL_RD_1 else
                 '1' when AR_USED_2(3) = '1' and AR_USED_2(2 downto 0) = AR_SEL_RD_2 else '0';

    AR_OUT_1 <= AR_OUT_1_I;
    AR_OUT_2 <= AR_OUT_2_I;

    ADR_IN_USE <= '1' when ADR_WB(32) = '1' and ADR_WB(31 downto 2) = ADR_EFF_I(31 downto 2) else -- Actual long word address.
                  '1' when ADR_WB(32) = '1' and ADR_WB(31 downto 2) - '1' = ADR_EFF_I(31 downto 2) else -- Lock a misaligned access.
                  '1' when ADR_WB(32) = '1' and ADR_WB(31 downto 2) + '1' = ADR_EFF_I(31 downto 2) else '0'; -- Lock a misaligned access.

    ADR_FORMAT: process
    begin
        wait until CLK = '1' and CLK' event;
        if STORE_ADR_FORMAT = '1' then
            SCALE <= EXT_WORD(10 downto 9);
            F_E <= EXT_WORD(8);
            B_S <= EXT_WORD(7);
            I_S <= EXT_WORD(6);
            BD_SIZE <= EXT_WORD(5 downto 4);
            I_IS <= EXT_WORD(2 downto 0);
        end if;
    end process ADR_FORMAT;

    ADDRESS_MODES: process(ADR_MODE, AMODE_SEL, AR, AR_IN_1, AR_PNTR_1, B_S, 
                           CLK, F_E, FETCH_MEM_ADR, I_S, I_IS, ISP_REG, ISP_M4, ISP_EARLY, MBIT, MSP_REG, 
                           PC_EW_OFFSET, PC_I, RESTORE_ISP_PC, SBIT, USE_DREG, USP_REG)
    -- The effective address calculation takes place in this process depending on the 
    -- selected addressing mode.
    -- The PC address (PC_I) used for the address calculation points to the first
    -- extension word used.
    variable ABS_ADDRESS        : std_logic_vector(31 downto 0);
    variable ADR_EFF_VAR        : std_logic_vector(31 downto 0);
    variable ADR_EFF_TMP        : std_logic_vector(31 downto 0);
    variable ADR_MUX            : std_logic_vector(31 downto 0);
    variable BASE_DISPL         : std_logic_vector(31 downto 0);
    variable I_S_IS             : std_logic_vector(3 downto 0); 
    variable INDEX              : std_logic_vector(31 downto 0) := x"00000000";    
    variable INDEX_SCALED       : std_logic_vector(31 downto 0);
    variable SCALE_V            : std_logic_vector(1 downto 0); -- [F93]
    variable MEM_ADR            : std_logic_vector(31 downto 0);
    variable OUTER_DISPL        : std_logic_vector(31 downto 0);
    variable PCVAR              : std_logic_vector(31 downto 0);
    variable PCBASE             : std_logic_vector(31 downto 0); -- F19/U2: suppressible PC base.
    begin
        I_S_IS := I_S & I_IS;        
        PCVAR := PC_I + PC_EW_OFFSET; -- This is the address of the extension word.

        if CLK = '1' and CLK' event then
            -- This logic selects the INDEX from one of the data registers or from one of 
            -- the address registers. Furthermore the index needs to be sign extended from 
            -- 8 bit to 32 bit or from 16 bit to 32 bit dependent on the address mode.
            -- In case of a long word operation, no extension is required. The index is 
            -- multiplied by 1, 2, 4 or 8.
            if STORE_ADR_FORMAT = '1' and EXT_WORD(15) = '0' and EXT_WORD(11) = '1' then
                INDEX := INDEX_IN; -- Long data register.
            elsif STORE_ADR_FORMAT = '1' and EXT_WORD(15) = '0' then
                for i in 31 downto 16 loop
                    INDEX(i) := INDEX_IN(15);
                end loop;
                INDEX(15 downto 0) := INDEX_IN(15 downto 0); -- Sign extended data register;
            elsif STORE_ADR_FORMAT = '1' and EXT_WORD(11) = '1' then -- Long address register.
                if EXT_WORD(14 downto 12) = "111" and SBIT = '1' and MBIT = '1' then
                    INDEX := MSP_REG;
                elsif EXT_WORD(14 downto 12) = "111" and SBIT = '1' and MBIT = '0' then
                    INDEX := ISP_REG;
                elsif EXT_WORD(14 downto 12) = "111" and SBIT = '0' then
                    INDEX := USP_REG;
                else
                    INDEX :=  AR(conv_integer(EXT_WORD(14 downto 12)));
                end if;
            elsif STORE_ADR_FORMAT = '1' then -- Sign extended address register;
                if EXT_WORD(14 downto 12) = "111" and SBIT = '1' and MBIT = '1' then
                    for i in 31 downto 16 loop
                        INDEX(i) := MSP_REG(15);
                    end loop;
                    INDEX(15 downto 0) := MSP_REG(15 downto 0);
                elsif EXT_WORD(14 downto 12) = "111" and SBIT = '1' and MBIT = '0' then
                    for i in 31 downto 16 loop
                        INDEX(i) := ISP_REG(15);
                    end loop;
                    INDEX(15 downto 0) := ISP_REG(15 downto 0);
                elsif EXT_WORD(14 downto 12) = "111" and SBIT = '0' then
                    for i in 31 downto 16 loop
                        INDEX(i) := USP_REG(15);
                    end loop;
                    INDEX(15 downto 0) := USP_REG(15 downto 0);
                else
                    for i in 31 downto 16 loop
                        INDEX(i) := AR(conv_integer(EXT_WORD(14 downto 12)))(15);
                    end loop;
                    INDEX(15 downto 0) := AR(conv_integer(EXT_WORD(14 downto 12)))(15 downto 0);
                end if;
            elsif IDX_TRK = '1' and IDX_L = '1' then -- [F97] forward the Dn write-back into INDEX.
                INDEX := INDEX_LIVE;
            elsif IDX_TRK = '1' then
                for i in 31 downto 16 loop
                    INDEX(i) := INDEX_LIVE(15);
                end loop;
                INDEX(15 downto 0) := INDEX_LIVE(15 downto 0);
            end if;
            -- [F97] Track while the previous instruction's write-back of the index Dn is pending, plus one
            -- clock to take the written value.
            if RESET = '1' then
                IDX_TRK <= '0';
            elsif STORE_ADR_FORMAT = '1' then
                IDX_N <= EXT_WORD(14 downto 12);
                IDX_L <= EXT_WORD(11);
                if EXT_WORD(15) = '0' and INDEX_PEND = '1' then IDX_TRK <= '1'; else IDX_TRK <= '0'; end if;
            elsif INDEX_PEND = '0' then
                IDX_TRK <= '0';
            end if;
            --
            -- [F93] at the STORE_ADR_FORMAT edge the SCALE signal still holds the previous brief word's scale
            -- (it is latched at this same edge in ADR_FORMAT), so take it from EXT_WORD here. Board: clr.l/clr.w
            -- (0,An,Dn*4)/(0,An,Dn*2) pairs in MiNT used each other's scale -> page map overwritten.
            if STORE_ADR_FORMAT = '1' then SCALE_V := EXT_WORD(10 downto 9); else SCALE_V := SCALE; end if;
            case SCALE_V is
                when "00" => INDEX_SCALED := INDEX; -- Multiple by 1.
                when "01" => INDEX_SCALED := INDEX(30 downto 0) & '0'; -- Multiple by 2.
                when "10" => INDEX_SCALED := INDEX(29 downto 0) & "00"; -- Multiple by 4.
                when others => INDEX_SCALED := INDEX(28 downto 0) & "000"; -- Multiple by 8.
            end case;
            --
            -- Register for memory indirect addressing modes.
            if STORE_MEM_ADR = '1' then
                MEM_ADR := AR_IN_1;
            end if;
            --
            -- The displacement needs to be sign extended from 8 bit to 32, from 16 bit to 32 bit or 
            -- not extended dependent on the address mode.
            if RESET = '1' then
                BASE_DISPL := (others => '0'); -- Null base displacement.
            elsif STORE_ADR_FORMAT = '1' and EXT_WORD(8) = '1' and EXT_WORD(5 downto 4) = "01" then
                BASE_DISPL := (others => '0'); -- Null base displacement.
            elsif STORE_ADR_FORMAT = '1' and EXT_WORD(8) = '0' then
                for i in 31 downto 8 loop
                    BASE_DISPL(i) := EXT_WORD(7);
                end loop;
                BASE_DISPL(7 downto 0) := EXT_WORD(7 downto 0);
            elsif STORE_D16 = '1' then
                for i in 31 downto 16 loop
                    BASE_DISPL(i) := EXT_WORD(15);
                end loop;
                BASE_DISPL(15 downto 0) := EXT_WORD;
            elsif STORE_D32_LO = '1' then
                if BD_SIZE = "10" then -- Word displacement.
                    for i in 31 downto 16 loop
                        BASE_DISPL(i) := EXT_WORD(15);
                    end loop;
                end if;
                BASE_DISPL(15 downto 0) := EXT_WORD;
            elsif STORE_D32_HI = '1' then
                BASE_DISPL(31 downto 16) := EXT_WORD;
            elsif STORE_DISPL = '1' then
                BASE_DISPL := DISPLACEMENT;
            end if;
            --
            -- The outer displacement may be NULL, WORD or LONG.
            if STORE_ADR_FORMAT = '1' and EXT_WORD(8) = '1' and EXT_WORD(1 downto 0) = "01" then
                OUTER_DISPL := (others => '0'); -- Null outer displacement.
            elsif STORE_OD_LO = '1' then
                if I_IS(1 downto 0) = "10" then
                    for i in 31 downto 16 loop
                        OUTER_DISPL(i) := EXT_WORD(15);
                    end loop;
                end if;
                OUTER_DISPL(15 downto 0) := EXT_WORD;
            elsif STORE_OD_HI = '1' then
                OUTER_DISPL(31 downto 16) := EXT_WORD;
            end if;
            --
            if STORE_ABS_LO = '1' then
                if AMODE_SEL = "000" then
                    for i in 31 downto 16 loop
                        ABS_ADDRESS(i) := EXT_WORD(15);
                    end loop;
                end if;
                ABS_ADDRESS(15 downto 0) := EXT_WORD;
            elsif STORE_ABS_HI = '1' then
                ABS_ADDRESS(31 downto 16) := EXT_WORD;
            end if;
        end if;

        -- F16/H23: base suppression was gated on FETCH_MEM_ADR, true only in
        -- FETCH_STATE = FETCH_MEMADR (control.vhd:492), a state entered ONLY
        -- when the extension word requests memory indirection (:1898/:1961).
        -- For a plain full-format EA with I/IS=000 the BS bit was decoded and
        -- then never acted on, so the base register was added regardless.
        -- Measured: A0=$9100 + bd=$9120 + Xn*2=$10 = $12230, where the manual
        -- requires $9130. The B_S and F_E terms already confine this to the
        -- suppressed case, so unsuppressed paths are untouched.
        --
        -- CORRECTION (F19/H27): this arm covers the An path ONLY. The second
        -- arm below, for ADR_MODE="111" / AMODE_SEL="011", is DEAD CODE -- the
        -- PC-relative EA is computed from PCVAR and NEVER READS ADR_MUX, so
        -- zeroing ADR_MUX there has no effect and never did, before or after
        -- F16. It is retained only because removing it is an unvectored change
        -- to shipped, silicon-confirmed code. PC-relative base suppression is
        -- handled by PCBASE in the "111" arm; see F19.
        if ADR_MODE = "110" and F_E = '1' and B_S = '1' then
            ADR_MUX := x"00000000"; -- Base register suppress (An path).
        elsif ADR_MODE = "111" and AMODE_SEL = "011" and F_E = '1' and B_S = '1' then
            ADR_MUX := x"00000000"; -- DEAD CODE: PC path uses PCBASE, not ADR_MUX.
        elsif USE_DREG = '1' then
            ADR_MUX := AR_IN_1;
        else
            case AR_PNTR_1 is
                when 7 =>
                    if SBIT = '1' and MBIT = '0' and ISP_EARLY = '1' then
                        -- [XT1] BUILD_STACK DATA_RDY clock: the ISP steps by 4 at this edge; the registered effective
                        -- address takes the stepped value from ISP_M4 (a register: no subtractor in this path).
                        -- ISP_REG has not changed for the whole stack bus cycle, so ISP_M4 = ISP_REG - 4 here.
                        ADR_MUX := ISP_M4;
                    elsif SBIT = '1' and MBIT = '0' then
                        ADR_MUX := ISP_REG;
                    elsif SBIT = '1' then
                        ADR_MUX := MSP_REG;
                    else
                        ADR_MUX := USP_REG;
                    end if;
                when others => ADR_MUX := AR(AR_PNTR_1);
            end case;
        end if;

        case ADR_MODE is
            -- when "000" | "001" => Direct address modes: no effective address required.
            when "010" | "011" | "100" =>
                ADR_EFF_VAR := ADR_MUX; -- (An), (An)+, -(An). 
            when "101" => -- Address register indirect with offset. Assembler syntax: (d16,An).
                ADR_EFF_VAR := ADR_MUX + BASE_DISPL; -- (d16,An).
            when "110" =>
                if F_E = '0' then -- Brief extension word.
                    ADR_EFF_VAR := ADR_MUX + BASE_DISPL + INDEX_SCALED; -- (d8, An, Xn, SIZE*SCALE). 
                else -- Full extension word.
                    case I_S_IS is
                        when "0000" => -- No memory indirect action.
                            ADR_EFF_VAR := ADR_MUX + BASE_DISPL + INDEX_SCALED; -- (bd, An, Xn, SIZE*SCALE).
                        -- F17/H24: "1000" is I_S = 1, the INDEX SUPPRESSED
                        -- full-format case with no memory indirection. It
                        -- shared the arm above and so added INDEX_SCALED
                        -- anyway. Measured: A0=$9100 + bd=4 + Xn*1=8 gave
                        -- $910C where the manual requires $9104. The suppressed
                        -- index INDIRECT variants ("1001"/"1010"/"1011") were
                        -- already correct below, which is why only the plain
                        -- case failed.
                        when "1000" => -- Index suppressed, no memory indirect.
                            ADR_EFF_VAR := ADR_MUX + BASE_DISPL; -- (bd, An).
                        when "0001" | "0010" | "0011" => -- Memory indirect preindexed.
                            if FETCH_MEM_ADR = '1' then
                                ADR_EFF_VAR := ADR_MUX + BASE_DISPL + INDEX_SCALED;
                            else
                                ADR_EFF_VAR := MEM_ADR + OUTER_DISPL;
                            end if;
                        when "0101" | "0110" | "0111" => -- Memory indirect postindexed.
                            if FETCH_MEM_ADR = '1' then
                                ADR_EFF_VAR := ADR_MUX + BASE_DISPL;
                            else
                                ADR_EFF_VAR := MEM_ADR + INDEX_SCALED + OUTER_DISPL;
                            end if;
                        when "1001" | "1010" | "1011" => -- Memory indirect.
                            if FETCH_MEM_ADR = '1' then
                                ADR_EFF_VAR := ADR_MUX + BASE_DISPL;
                            else
                                ADR_EFF_VAR := MEM_ADR + OUTER_DISPL;
                            end if;
                        when others =>
                            ADR_EFF_VAR := (others => '-'); -- Reserved, don't care.
                    end case;
                end if;
            when "111" =>
                case AMODE_SEL is
                    when "000" | "001" =>
                        ADR_EFF_VAR := ABS_ADDRESS;
                    when "010" => -- (d16, PC).
                        ADR_EFF_VAR := PCVAR + BASE_DISPL;
                    when "011" =>
                        -- F19/U2: the PC arm computes from PCVAR directly and
                        -- never reads ADR_MUX, so F16's ADR_MUX zeroing for
                        -- AMODE_SEL="011" was DEAD CODE and BS had no effect on
                        -- PC-relative forms. PCBASE is the suppressible base.
                        -- Measured: BS=1 with bd=$9120, Xn*2=$10 read $00000000
                        -- instead of the $9130 marker.
                        if F_E = '1' and B_S = '1' then
                            PCBASE := x"00000000";
                        else
                            PCBASE := PCVAR;
                        end if;
                        if F_E = '0' then -- Brief extension word.
                            -- Assembler syntax: (d8,PC,Xn.SIZE*SCALE).
                            ADR_EFF_VAR := PCVAR + BASE_DISPL + INDEX_SCALED; -- (d8, PC, Xn, SIZE*SCALE).
                        else -- Full extension word.
                            case I_S_IS is
                                when "0000" => -- No memory indirect action.
                                    ADR_EFF_VAR := PCBASE + BASE_DISPL + INDEX_SCALED; -- (bd, PC, Xn, SIZE*SCALE).
                                -- F20/U1: "1000" is IS=1, index suppressed. It
                                -- shared the arm above and added INDEX_SCALED
                                -- anyway -- the same defect F17 fixed on the An
                                -- path, left behind on the PC path. Measured:
                                -- the read landed 8 bytes on, exactly d2*scale.
                                when "1000" => -- Index suppressed, no memory indirect.
                                    ADR_EFF_VAR := PCBASE + BASE_DISPL; -- (bd, PC).
                                when "0001" | "0010" | "0011" => -- Memory indirect preindexed.
                                    if FETCH_MEM_ADR = '1' then
                                        ADR_EFF_VAR := PCBASE + BASE_DISPL + INDEX_SCALED;
                                    else
                                        ADR_EFF_VAR := MEM_ADR + OUTER_DISPL;
                                    end if;
                                when "0101" | "0110" | "0111" => -- Memory indirect postindexed.
                                    if FETCH_MEM_ADR = '1' then
                                        ADR_EFF_VAR := PCBASE + BASE_DISPL;
                                    else
                                        ADR_EFF_VAR := MEM_ADR + INDEX_SCALED + OUTER_DISPL;
                                    end if;
                                when "1001" | "1010" | "1011" => -- Memory indirect.
                                    if FETCH_MEM_ADR = '1' then
                                        ADR_EFF_VAR := PCBASE + BASE_DISPL;
                                    else
                                        ADR_EFF_VAR := MEM_ADR + OUTER_DISPL;
                                    end if;
                                when others =>
                                    ADR_EFF_VAR := (others => '-'); -- Reserved, don't care.
                            end case;
                        end if;
                    when others =>
                        ADR_EFF_VAR := (others => '-'); -- Don't care, while not used.
                end case;
            when others =>
                ADR_EFF_VAR := (others => '-'); -- Result not required.
        end case;
        --
        if CLK = '1' and CLK' event then
            if RESTORE_ISP_PC = '1' then
                ADR_EFF_I <= ADR_OFFSET; -- During system initialization.
            elsif STORE_AEFF = '1' then -- Used for MOVEM.
                ADR_EFF_I <= ADR_EFF_TMP + ADR_OFFSET; -- Keep the effective address. See also CONTROL section.
            else -- Normal operation:
                ADR_EFF_I <= ADR_EFF_VAR + ADR_OFFSET;
                ADR_EFF_TMP := ADR_EFF_VAR;
            end if;
        end if;
    end process ADDRESS_MODES;

    ADR_EFF <= ADR_EFF_I;
    ADR_EFF_WB <= ADR_WB(31 downto 0);
    
    -- Data outputs:
    AR_OUT_1_I <= ISP_REG when ISP_RD = '1' else
                  MSP_REG when MSP_RD = '1' else
                  USP_REG when USP_RD = '1' else
                  AR(AR_PNTR_1) when AR_PNTR_1 < 7 else 
                  MSP_REG when SBIT = '1' and MBIT = '1' else
                  ISP_REG when SBIT = '1' and MBIT = '0' else USP_REG;

    AR_OUT_2_I <= AR(AR_PNTR_2) when AR_PNTR_2 < 7 else 
                  MSP_REG when SBIT = '1' and MBIT = '1' else
                  ISP_REG when SBIT = '1' and MBIT = '0' else USP_REG;

    PC <= PC_I;

    PROGRAM_COUNTER: process
    -- Note: PC_LOAD and PC_ADD_DISPL must be highest
    -- prioritized. The reason is that in case of jumps
    -- or branches the Ipipe is flushed in connection
    -- with PC_INC. In such cases PC_LOAD or PC_ADD_DISPL
    -- are asserted simultaneously with PC_INC.
    begin
        wait until CLK = '1' and CLK' event;
        if RESET = '1' then
            PC_I <= (others => '0');
        elsif PC_LOAD = '1' then
            PC_I <= AR_IN_1;
        elsif PC_ADD_DISPL = '1' then
            PC_I <= PC_I + DISPLACEMENT;
        elsif PC_RESTORE = '1' then
            PC_I <= AR_IN_1; -- Keep prioritization!
        elsif PC_INC = '1' then
            PC_I <= PC_I + PC_OFFSET;
        end if;
    end process PROGRAM_COUNTER;

    STACK_POINTERS: process
    -- The registers are modeled in a way
    -- that write and simultaneously increment
    -- decrement and others are possible for
    -- different registers.
    begin
        wait until CLK = '1' and CLK' event;

        ---------------------------------------- MSP section ----------------------------------------
        if RESET = '1' then
            MSP_REG <= (others => '0');
        elsif AR_WR_1 = '1' and AR_PNTR_WB_1 = 7 and MSBIT = "11" then
            MSP_REG <= AR_IN_1; -- Always written long.
        end if;
        
        if AR_INC = '1' and AR_PNTR_1 = 7 and SBIT = '1' and MBIT = '1' then
            case OP_SIZE is
                when BYTE       => MSP_REG <= MSP_REG + "10"; -- Increment by two!
                when WORD       => MSP_REG <= MSP_REG + "10"; -- Increment by two.
                when others     => MSP_REG <= MSP_REG + "100"; -- Increment by four, (LONG).
            end case;
        end if;
        
        if (ISP_DEC = '1' and MBIT = '1') or (AR_DEC = '1' and AR_PNTR_1 = 7 and SBIT = '1' and MBIT = '1') then -- F8/H14: master-stack build decrement.
            case OP_SIZE is
                when BYTE       => MSP_REG <= MSP_REG - "10"; -- Decrement by two!
                when WORD       => MSP_REG <= MSP_REG - "10"; -- Decrement by two.
                when others     => MSP_REG <= MSP_REG - "100"; -- Decrement by four, (LONG).
            end case;        
        end if;

        if MSP_WR = '1' then
            MSP_REG <= AR_IN_1;
        elsif SP_ADD_DISPL = '1' and AR_INC = '1' and SBIT = '1' and MBIT = '1' then
            MSP_REG <= MSP_REG + DISPLACEMENT + "100"; -- Used for RTD. 
        elsif SP_ADD_DISPL = '1' and SBIT = '1' and MBIT = '1' then
            MSP_REG <= MSP_REG + DISPLACEMENT; 
        end if;

        ---------------------------------------- ISP section ----------------------------------------
        -- [COLD] One chain.  Four separate ifs all wrote ISP_REG;
        -- GHDL last-assignment-wins, Gowin need not.  ISP_WR (reset
        -- SSP fetch) is highest so RESTORE_ISP cannot lose to RESET
        -- or a same-cycle DEC.
        if ISP_WR = '1' then
            ISP_REG <= AR_IN_1;
        elsif AR_WR_1 = '1' and AR_PNTR_WB_1 = 7 and MSBIT = "01" then
            ISP_REG <= AR_IN_1;
        elsif RESET = '1' then
            ISP_REG <= (others => '0');
        elsif AR_INC = '1' and AR_PNTR_1 = 7 and SBIT = '1' and MBIT = '0' then
            case OP_SIZE is
                when BYTE       => ISP_REG <= ISP_REG + "10";
                when WORD       => ISP_REG <= ISP_REG + "10";
                when others     => ISP_REG <= ISP_REG + "100";
            end case;
        elsif (ISP_DEC = '1' and MBIT = '0') or (AR_DEC = '1' and AR_PNTR_1 = 7 and SBIT = '1' and MBIT = '0') then
            case OP_SIZE is
                when BYTE       => ISP_REG <= ISP_REG - "10";
                when WORD       => ISP_REG <= ISP_REG - "10";
                when others     => ISP_REG <= ISP_REG - "100";
            end case;
        elsif SP_ADD_DISPL = '1' and AR_INC = '1' and SBIT = '1' and MBIT = '0' then
            ISP_REG <= ISP_REG + DISPLACEMENT + "100";
        elsif SP_ADD_DISPL = '1' and SBIT = '1' and MBIT = '0' then
            ISP_REG <= ISP_REG + DISPLACEMENT;
        end if;

        ISP_M4 <= ISP_REG - "100"; -- [XT1]

        ---------------------------------------- USP section ----------------------------------------
        if RESET = '1' then
            USP_REG <= (others => '0');
        elsif AR_WR_1 = '1' and AR_PNTR_WB_1 = 7 and MSBIT(0) = '0' then
            USP_REG <= AR_IN_1; -- Always written long.
        end if;
        
        if AR_INC = '1' and AR_PNTR_1 = 7 and SBIT = '0' then
            case OP_SIZE is
                when BYTE       => USP_REG <= USP_REG + "10"; -- Increment by two!
                when WORD       => USP_REG <= USP_REG + "10"; -- Increment by two.
                when others     => USP_REG <= USP_REG + "100"; -- Increment by four, (LONG).
            end case;
        end if;
        
        if AR_DEC = '1' and AR_PNTR_1 = 7 and SBIT = '0' then
            case OP_SIZE is
                when BYTE       => USP_REG <= USP_REG - "10"; -- Decrement by two!
                when WORD       => USP_REG <= USP_REG - "10"; -- Decrement by two.
                when others     => USP_REG <= USP_REG - "100"; -- Decrement by four, (LONG).
            end case;
        end if;
        
        if USP_WR = '1' then
            USP_REG <= AR_IN_1;
        elsif SP_ADD_DISPL = '1' and AR_INC = '1' and SBIT = '0' then
            USP_REG <= USP_REG + DISPLACEMENT + "100"; -- Used for RTD. 
        elsif SP_ADD_DISPL = '1' and SBIT = '0' then
            USP_REG <= USP_REG + DISPLACEMENT; 
        end if;

        if AR_WR_2 = '1' and AR_PNTR_WB_2 = 7 and MSBIT = "11" then
            MSP_REG <= AR_IN_2; -- Used for EXG and UNLK.
        elsif AR_WR_2 = '1' and AR_PNTR_WB_2 = 7 and MSBIT = "01" then
            ISP_REG <= AR_IN_2; -- Used for EXG and UNLK.
        elsif AR_WR_2 = '1' and AR_PNTR_WB_2 = 7 then
            USP_REG <= AR_IN_2; -- Used for EXG and UNLK.
        end if;
    end process STACK_POINTERS;

    ADDRESS_REGISTERS: process
    -- The registers are modeled in a way
    -- that write and simultaneously increment
    -- decrement and others are possible for
    -- different registers.
    begin
        -- 
        wait until CLK = '1' and CLK' event;

        if RESET = '1' then
            AR <= (others => (Others => '0'));
        end if;
        
        if AR_WR_1 = '1' and AR_PNTR_WB_1 < 7 then
            AR(AR_PNTR_WB_1) <= AR_IN_1; -- Always written long.
        end if;
        
        if AR_INC = '1' and AR_PNTR_1 < 7 then
            case OP_SIZE is
                when BYTE       => AR(AR_PNTR_1) <= AR(AR_PNTR_1) + '1';
                when WORD       => AR(AR_PNTR_1) <= AR(AR_PNTR_1) + "10";
                when others     => AR(AR_PNTR_1) <= AR(AR_PNTR_1) + "100";
            end case;
        end if;
        
        if AR_DEC = '1' and AR_PNTR_1 < 7 then
            case OP_SIZE is
                when BYTE       => AR(AR_PNTR_1) <= AR(AR_PNTR_1) - '1';
                when WORD       => AR(AR_PNTR_1) <= AR(AR_PNTR_1) - "10";
                when others     => AR(AR_PNTR_1) <= AR(AR_PNTR_1) - "100";
            end case;
        end if;        

        if AR_WR_2 = '1' and AR_PNTR_WB_2 < 7 then
            AR(AR_PNTR_WB_2) <= AR_IN_2; -- Used for EXG and UNLK.
        end if;
    end process ADDRESS_REGISTERS;

    FCODES: process
    -- These flip flops provide the alternate function
    -- code registers.
    variable SFC_REG : std_logic_vector(2 downto 0);
    variable DFC_REG : std_logic_vector(2 downto 0);
    begin
        wait until CLK = '1' and CLK' event;
        if DFC_WR = '1' then
            DFC_REG := AR_IN_1(2 downto 0);
        end if;
        --
        if SFC_WR = '1' then
            SFC_REG := AR_IN_1(2 downto 0);
        end if;
        --
        DFC <= DFC_REG;
        SFC <= SFC_REG;
    end process FCODES;
end BEHAVIOR;